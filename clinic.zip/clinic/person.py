class Person:
    def __init__(self, name,ssn) -> None:
        self._name = name
        self._ssn = ssn
        
    @property
    def name(self):
        return self._name
    @name.setter
    def name(self, value):
        self._name = value
    @property
    def ssn(self):
        return self._ssn
    @ssn.setter
    def ssn(self, value):
        self._ssn = value
  