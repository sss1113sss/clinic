from person import Person
from patient import Patient
from doctor import Doktor

class Clinic:
    def __init__(self) -> None:
        self.clinic_list = [Patient,Doktor]

    def add_patient(self, patient: Patient):
        clist = self.clinic_list
        return patient.add_patient(patient)
    def add_doktor(self, doktor: Doktor):
        clist = self.clinic_list
        return doktor.add_doktor(doktor)    
