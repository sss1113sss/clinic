from person import Person

class Patient(Person):
    def __init__(self) -> None:
        self._plist: list[Patient] = []
    def add_patient(self, patient: Person):
        # if self._name == beverage.name:
        self._name = patient._name
        self._ssn = patient._ssn
        
        self._plist.append(patient)
        return 'qo\'shildi'
        # return 'qo\'sha olmadim'
    
    def getPatient(self):
        for i in self._plist:
            print(i.name, '-->', i.ssn)

    