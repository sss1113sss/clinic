from person import Person

class Doktor(Person):
    def __init__(self) -> None:
         self._plist: list[Doktor] = []
    def add_doktor(self, doktor: Person):
        # if self._name == beverage.name:
        self._name = doktor._name
        self._ssn = doktor._ssn
        
        self._plist.append(doktor)
        return 'qo\'shildi'
        # return 'qo\'sha olmadim'
    
    def getPatient(self):
        for i in self._plist:
            print(i.name, '-->', i.ssn)

    